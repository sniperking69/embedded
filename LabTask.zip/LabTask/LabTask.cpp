
#include "Arduino.h"
#include "LabTask.h"

LabTask::LabTask(int a, int b, int c, int d){
  _pin1 = a;
  _pin2 = b;
  _pin3 = c;
  _pin4 = d;
  }

void LabTask::begin(){
  pinMode(_pin1,OUTPUT);
  pinMode(_pin2,OUTPUT);
  pinMode(_pin3,OUTPUT);
  pinMode(_pin4,OUTPUT);
  }

void LabTask::upCount(){
  for(int i=0;i<16;i++) 
  {  
   int a=i%2;        
   int b=i/2 %2;     
   int c=i/4 %2;        
   int d=i/8 %2;  
   digitalWrite(_pin1,d);   
   digitalWrite(_pin2,c);   
   digitalWrite(_pin3,b);    
   digitalWrite(_pin4,a);    
   delay(1000);
   if((a == 1)&&(b == 1) && (c == 1) && (d == 1)){
    i = 0;}
  }
}

void LabTask::downCount(){
  for(int i=16;i>0;i--)  // increment automatically from 0 to 15 
  {  
   int a=i%2;      // calculate LSB   
   int b=i/2 %2;     
   int c=i/4 %2;        
   int d=i/8 %2;  //claculate MSB
   digitalWrite(_pin1,d);   //write MSB
   digitalWrite(_pin2,c);   
   digitalWrite(_pin3,b);    
   digitalWrite(_pin4,a);  // write LSB  
   delay(1000);
   if((a == 0)&&(b == 0) && (c == 0) && (d == 0)){
    i = 16;}
  }
}

void LabTask::shiftRight(int sec){
  digitalWrite(_pin4,HIGH);
  delay(sec);
  digitalWrite(_pin4,LOW);
  digitalWrite(_pin3,HIGH);
  delay(sec);
  digitalWrite(_pin3,LOW);
  digitalWrite(_pin2,HIGH);
  delay(sec);
  digitalWrite(_pin2,LOW);
  digitalWrite(_pin1,HIGH);
  delay(sec);
  digitalWrite(_pin1,LOW);
  }

void LabTask::shiftLeft(int sec){
  digitalWrite(_pin1,HIGH);
  delay(sec);
  digitalWrite(_pin1,LOW);
  digitalWrite(_pin2,HIGH);
  delay(sec);
  digitalWrite(_pin2,LOW);
  digitalWrite(_pin3,HIGH);
  delay(sec);
  digitalWrite(_pin3,LOW);
  digitalWrite(_pin4,HIGH);
  delay(sec);
  digitalWrite(_pin4,LOW);
  }

void LabTask::allOff(){
  digitalWrite(_pin1,LOW);
  digitalWrite(_pin2,LOW);
  digitalWrite(_pin3,LOW);
  digitalWrite(_pin4,LOW);
  }
