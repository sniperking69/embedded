
 
#ifndef LabTask_h
#define LabTask_h
#include "Arduino.h"
class LabTask{
  private:
    int _pin1;
    int _pin2;
    int _pin3;
    int _pin4;
    
  public:
    LabTask(int a, int b, int c, int d);
    void begin();
    void upCount();
    void downCount();
    void shiftRight(int sec);
    void shiftLeft(int sec);
    void allOff();
  };
#endif
